# Suika Stay Home

Suika Stay Home is a zero-player game and artwork by Billy Rennekamp and Joon Yeon Park. It is a fork of a copy of a clone of the popular [Suika Game](https://en.wikipedia.org/wiki/Suika_Game) on Nintendo Switch, re-skinned and modified so the player is a passive participant. Unofficial clones of the game, called "Suikalikes", are rampant and "Suika Stay Home" joins their ranks, composed of copied, re-created and original clipart, acting as prizes for a Gashapon vending machine that only accepts coins of EU origin.

----

# Suika Game

スイカゲーム clone on Nintendo Switch

## Original code
https://github.com/kairess/suika-game.git  
https://github.com/paulantoine2/suika
